<!DOCTYPE html>
<html>
<body>

<form name="sysuser" id="sysuser" action="login_post.php" method="post">
<style type="text/css">
<!--
.style2 {font-size: 14px}
-->
</style>
<table width="499" border="0" cellpadding="0" cellspacing="0" >
  <!--DWLayoutTable-->
  <tr>
    <td width="3" rowspan="9">&nbsp;</td>
    <td height="26" colspan="3" align="center" valign="middle">System Login </td>
    </tr>
  <tr>
    <td width="345" height="37">&nbsp;</td>
    <td width="58">&nbsp;</td>
    <td width="7"></td>
  </tr>
  
  <tr>
    <td height="27" colspan="2" align="right" valign="middle">userid
      <input name="userid" type="text" id="userid" size="30" maxlength="6" /></td>
    <td></td>
  </tr>
  
  <tr>
    <td height="27" colspan="2" align="right" valign="middle"><span class="style2">Password
        <input name="password" type="password" id="password" size="30" maxlength="30" />
    </span></td>
    <td></td>
  </tr>
  <tr>
    <td height="32">&nbsp;</td>
    <td>&nbsp;</td>
    <td></td>
  </tr>
  <tr>
    <td height="2" colspan="2" valign="top"><hr></td>
    <td></td>
  </tr>
  
  <tr>
    <td height="32">&nbsp;</td>
    <td valign="middle"><input type="submit" name="Submit" value="Submit" /></td>
    <td></td>
  </tr>
  <tr>
    <td height="45">&nbsp;</td>
    <td>&nbsp;</td>
    <td></td>
  </tr>
</table>

</form>
</body>
</html>

