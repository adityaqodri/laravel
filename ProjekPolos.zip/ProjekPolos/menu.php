<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<table width="176" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <th width="176" height="45" valign="middle">&lt;&gt; MENU &lt;&gt;</th>
  </tr>
  <tr>
    <td height="40" align="right" valign="middle"><a href="home.php">HOME &lt;&gt; </a></td>
  </tr>
  <tr>
    <td height="40" align="right" valign="middle"><a href="#">MY ACCOUNT &lt;&gt;</a></td>
  </tr>
  
  <tr>
    <td height="40" align="right" valign="middle"><a href="#">KONFIRMASI PEMBAYARAN &lt;&gt; </a></td>
  </tr>
  <tr>
    <th height="40">&lt;&gt; MASTER &lt;&gt; </th>
  </tr>
  <tr>
    <td height="40" align="right" valign="middle"><a href="homejadwaltraining.php">JADWAL TRAINING &lt;&gt;</a></td>
  </tr>
  <tr>
    <td height="2"></td>
  </tr>
</table>
</body>
</html>
