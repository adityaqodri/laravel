<?php
	
		$kaleng = 84000;
		$diskon = 0;
		$total = 0;
		$totalhargabeli = 0;
		
		$ajumlah = $_POST['ajumlah'];
		echo "Jumlah kaleng : " .$ajumlah;
		
		echo"<br>";
		
		$totalhargabeli = $ajumlah * $a;
?>