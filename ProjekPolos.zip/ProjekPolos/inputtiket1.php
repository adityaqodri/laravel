<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>


<body bgcolor="#fff">
	<br/>
<form name="kaleng" id="kaleng" method="post" action="hometiketcek.php">
<table align="center"width="410" border="0" cellpadding="0" cellspacing="0">
	  <!--DWLayoutTable-->
  	  <tr bgcolor="#66CC99">
  	    <td height="40" align="right" valign="middle">Training ID/ Nama Training </td>
  	    <td align="center" valign='middle'> :</td>
  	    <td align="right" valign='middle'>NC1 / NEW CHAPTER 1 </td>
    </tr>
    <tr bgcolor="#66CC99">
    	<td width="106" height="40" align="right" valign="middle"><div align="center">Jumlah Tiket </div></td>
    	<td width="13" valign='middle'><div align="center">:</div></td>
  	  <td width="225" align="right" valign='middle'>2650000x
  	    <input name="jumlahtiket" type="text" id="jumlahtiket" /></td>
  	</tr>
	<tr bgcolor="#CCCC00">
  		<td height="34" align="center" valign="middle"><!--DWLayoutEmptyCell-->&nbsp;</td>
   		 <td colspan="2" align="right" valign="top"><input type="submit" name="Submit" value="Submit" />&nbsp;</td>
  	</tr>
</table>
</form>
		
		
</body>
</html>
