<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
body{ 
	margin:0px auto;
	background-color:#000165;
	}
	</style>
</head>

<body>
<table width="1046" border="0" cellpadding="0" cellspacing="0" align="center" bgcolor="#FFFFFF">
  <!--DWLayoutTable-->
  <tr>
    <td height="35" colspan="7" align="center" valign="middle"><marquee> Banyak Program Untuk Upgrade diri Anda !!!!! </marquee> </td>
  </tr>
  <tr>
    <td width="38" rowspan="4" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td width="270" height="250" valign="top"><a href="homeinputtiket1.php"><img src="images/trainingNC.jpg" width="268" height="317" border="0" /></a></td>
    <td width="39" rowspan="3" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td width="292" valign="top"><img src="images/trainingkids.jpg" width="294" height="317" /></td>
    <td width="55" rowspan="3" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td width="299" valign="top"><img src="images/trainingteens.jpg" width="321" height="317" /></td>
  <td width="53" rowspan="4" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
  
  <tr>
    <td height="44" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
  
  <tr>
    <td height="241" valign="top"><img src="images/trainingNC.jpg" width="268" height="317" /></td>
    <td valign="top"><img src="images/trainingkids.jpg" width="294" height="317" /></td>
    <td valign="top"><img src="images/trainingteens.jpg" width="321" height="317" /></td>
  </tr>
  
  <tr>
    <td height="33" colspan="5" align="center" valign="middle"> <marquee> Belilah Selagi Masih Harga PROMO LEBARAN !!!! </marquee> </td>
  </tr>
</table>
</body>
</html>
