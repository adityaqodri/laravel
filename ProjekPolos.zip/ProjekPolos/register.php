
<style type="text/css">
<!--
	margin:0px auto;
	background-color:#000165;
	
.style2 {font-size: 14px}
-->
</style>
<table width="499" border="0" cellpadding="0" cellspacing="0" background="images/menaraa.jpg">
  <!--DWLayoutTable-->
  <tr>
    <td width="248" rowspan="11" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td width="153" height="49">&nbsp;</td>
    <td width="90">&nbsp;</td>
    <td width="8"></td>
  </tr>
  <tr>
    <td height="27" colspan="2" align="right" valign="middle">NAMA
      <input name="userid" type="text" id="userid" size="30" maxlength="30" /></td>
    <td></td>
  </tr>
  
  <tr>
    <td height="27" colspan="2" align="right" valign="middle"><span class="style2">Password
        <input name="password" type="text" id="passpeserta" size="30" maxlength="30" />
    </span></td>
    <td></td>
  </tr>
  <tr>
    <td height="27" colspan="2" align="right" valign="middle">Email
      <input name="=email" type="text" id="email" size="30" maxlength="30" /></td>
    <td></td>
  </tr>
  <tr>
    <td height="30" colspan="2" align="right" valign="middle">Telepon
      <input name="telepon_peserta" type="text" id="telepon_peserta" size="30" maxlength="30" /></td>
    <td></td>
  </tr>
  <tr>
    <td height="30" colspan="2" align="right" valign="middle">Tgl. Lahir
      <input name="tgl_lahir" type="text" id="tgl_lahir" size="20" maxlength="20" /></td>
    <td></td>
  </tr>
  <tr>
    <td height="30" colspan="2" align="right" valign="middle">Alamat
      <input name="alamat" type="text" id="alamat" size="20" maxlength="20" /></td>
    <td></td>
  </tr>
  <tr>
    <td height="2" colspan="2" valign="top"><hr></td>
    <td></td>
  </tr>
  <tr>
    <td height="24">&nbsp;</td>
    <td valign="top"><a href="login.php">login?</a></td>
    <td></td>
  </tr>
  <tr>
    <td height="32"></td>
    <td valign="middle"><input type="submit" name="Submit" value="Submit" /></td>
    <td></td>
  </tr>
  <tr>
    <td height="13"></td>
    <td></td>
    <td></td>
  </tr>
</table>
