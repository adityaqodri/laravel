<?php 
include("koneksidb.php");

$id = $_POST['id'];
$nama = $_POST['nama'];
$nohp = $_POST['nohp'];
$email = $_POST['email'];
$password = $_POST['pass'];


$koneksikedb->query("INSERT INTO login VALUES('".$id."', '".$nama."', '".$nohp."', '".$email."', '".$password."')");
header("Location:login.php?page=login");


?>

<div>
		<?php 
			if(isset($_GET['page'])){
				$page = $_GET['page'];
		 
				switch ($page) {
					case 'simpanuser':
						include "simpanuser.php";
						break;
					case 'login':
					include "login.php";
						break;			
					default:
						echo "<center><h3>Maaf. Halaman tidak di temukan !</h3></center>";
						break;
				}
			}else{
				include "login.php";
			}
	 ?>
	</div>


    <div>
	<?php 
		if(isset($_POST['login'])){
			$page = $_POST['login'];
		$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
		$password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

		$sql = "SELECT * FROM users WHERE nohp=:nohp OR email=:email";
		$stmt = $readme->prepare($sql);
		
		// bind parameter ke query
		$params = array(
			":nohp" => $nohp,
			":email" => $username
		);

		$stmt->execute($params);

		$koneksikedb = $stmt->fetch(PDO::FETCH_ASSOC);

		// jika user terdaftar
		if($koneksikedb){
			// verifikasi password
			if(password_verify($password, $koneksikedb["password"])){
				// buat Session
				session_start();
				$_SESSION["login"] = $koneksikedb;
				// login sukses, alihkan ke halaman timeline
				header("Location: index.php");
			}
		}
	}
	?>
