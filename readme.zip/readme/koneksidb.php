<?php
$server = "localhost";
$user = "root";
$pass = "";
$dbname = "readme";

$koneksikedb = mysqli_connect($server, $user, $pass, $dbname);
?>




