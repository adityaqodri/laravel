
	<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-1">
					<div class="login-form"><!--login form-->
						<h2>Masuk </h2>
						<form >
							<input type="text" placeholder="Id" />
							<input type="text" placeholder="Nomor Handphone" />
							<span>
								<input type="checkbox" class="checkbox"> 
								Tetap Masuk
							</span>
							<button type="submit" class="btn btn-default">Masuk</button>
						</form>
					</div><!--/login form-->
				</div>

				<div class="col-sm-1">
					<h2 class="or">Atau</h2>
				</div>

				<div class="col-sm-4">
					<div class="signup-form"><!--sign up form-->
						<h2>Belum Punya Akun, Daftar Dulu Ya!</h2>
						<form method="post" action="index.php?page=simpanuser">
							<input type="text" name="id" placeholder="Id"/>
							<input type="text" name="nama" placeholder="Nama" />
							<input type="text" name="nohp" placeholder="Nomor Handphone"/>
							<input type="email" name="email" placeholder="Alamat Email"/>
							<input type="password" name="pass" placeholder="Password"/>
							<button type="submit" class="btn btn-default">Daftar</button>
						</form>
					</div><!--/sign up form-->
				</div>
			</div>
		</div>
	</section><!--/form-->
