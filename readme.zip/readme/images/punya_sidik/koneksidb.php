<?php
$server = "localhost";
$user = "root";
$pass = "";
$dbname = "login_sidik";

$koneksikedb = mysqli_connect($server, $user, $pass, $dbname);
?>