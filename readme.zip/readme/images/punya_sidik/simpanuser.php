<?php 
include("koneksidb.php");

$id = $_POST['id'];
$nama = $_POST['nama'];
$nohp = $_POST['nohp'];
$email = $_POST['email'];
$password = $_POST['pass'];


$koneksikedb->query("INSERT INTO login VALUES('".$id."', '".$nama."', '".$nohp."', '".$email."', '".$password."')");
header("Location:index.php?page=login");

?>