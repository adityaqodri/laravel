<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Readme</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<header id="header"><!--header-->	
		<div class="header-middle"><!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="index.php"><img src="images/thing/README.png" alt="" /></a>
						</div>
						<div class="btn-group">
					
						</div>
					</div>
					<div class="col-sm-8">
						<div class="shop-menu pull-right">
							<ul class="nav navbar-nav">
								<li><a href="profile.php"><i class="fa fa-user"></i> Akun</a></li>
								<li><a href="wishlist.php"><i class="fa fa-star"></i> Wishlist</a></li>
								<li><a href="login.php"><i class="fa fa-lock"></i> Masuk/Daftar</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom"><!--header-bottom-->
			<div class="container">
				<div class="row">
					<div class="col-sm-9">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>

						<div class="mainmenu pull-left">
							<ul class="nav navbar-nav collapse navbar-collapse">
								<li><a href="index.php">Beranda</a></li>		
								<li><a href="minjeminbuku.php" > <b>Saya Ingin Meminjamkan Buku</b></a></li>								 
								<li><a href="blog.php">Blog </i>
								<li><a href="contact-us.php">Kontak</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="search_box pull-right">
							<input type="text" placeholder="Search"/>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->

	<section id="slider"><!--slider-->
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div id="slider-carousel" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
							<li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
							<li data-target="#slider-carousel" data-slide-to="1"></li>
							<li data-target="#slider-carousel" data-slide-to="2"></li>
						</ol>
						
						<div class="carousel-inner">
							<div class="item active">
								<div class="col-sm-6">
									<h1><span>READ</span>ME</h1>
									<h2>Pinjam & Meminjamkan Buku</h2>
									<p>Buku dari Mardigu Wowiek Prasantyo, bercerita tentang bagai mana cara mensetting pemikiran kita aga menjadi orang sukses</p>
									<button type="button" class="btn btn-default get">Pinjam Buku Ini</button>
								</div>
								
								<div class="col-sm-6">
									<img src="images/thing/buku1.jpeg" class="girl img-responsive" alt="" />
								</div>
							</div>

							<div class="item">
								<div class="col-sm-6">
									<h1><span>READ</span>ME</h1>
									<h2>When I Meet You</h2>
									<p>Takdir seolah berkonspirasi dengan alam mempertemukan dirinya dengan pria yang menggoreskan luka dalam hatinya. Dan kini luka itu kembali mengangga.</p>
									<button type="button" class="btn btn-default get">Pinjam Buku Ini</button>
								</div>
								
								<div class="col-sm-6">
									<img src="images/thing/buku3.jpeg" class="girl img-responsive" alt="" />
								</div>
							</div>
							
							<div class="item">
								<div class="col-sm-6">
									<h1><span>READ</span>ME</h1>
									<h2>Berfikir dan Berjiwa Besar</h2>
									<p>Keberhasilan berarti banyak hal yang mengagumkan dan positif. Keberhasilan berarti kesejahteraan pribadi: rumah yang bagus, liburan, perjalanan, pengalaman baru, jaminan keuangan untuk anak dan istri. Keberhasilan berarti memperoleh kehormatan, kepemimpinan, disegani oleh rekan bisnis, dan popular di kalangan teman. Keberhasilan (prestasi) adalah tujuan hidup!.</p>
									<button type="button" class="btn btn-default get">Pinjam Buku Ini</button>
								</div>
								
								<div class="col-sm-6">
									<img src="images/thing/buku5.jpeg" class="girl img-responsive" alt="" />
								</div>
							</div>
						</div>
							
						<a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
							<i class="fa fa-angle-left"></i>
						</a>
						<a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
							<i class="fa fa-angle-right"></i>
						</a>
					</div>
					
				</div>
			</div>
		</div>
	</section><!--/slider-->
	
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Category</h2>
						<div class="panel-group category-products" id="accordian"><!--category-productsr-->
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Dongen</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Biografi</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Sejarah</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Finansial</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Romance</h4>
								</div>
							</div>
							
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Sains</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Fiksi</h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Agama</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Sejarah</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Psikologi</h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Kamus</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#">Pengembangan Diri</a></h4>
								</div>
							</div>
						</div><!--/category-products-->
					
						
						<div class="shipping text-center"><!--event-->
							<img src="images/thing/event.jpg" alt="" />
						</div><!--/event-->
					
					</div>
				</div>
				
				<div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Buku Tersedia</h2>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="images/home/buku1.jpg" alt="" />
											<h2>7 Hari</h2>
											<h6>Daun Yang Jatuh Tak Pernah Membenci</h6>
											<p>Tere Liye</p>
											<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>7 Hari</h2>
												<h6>Daun Yang Jatuh Tak Pernah Membenci</h6>
												<p>Tere Liye</p>
												<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
											</div>
										</div>
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
									</ul>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="images/home/buku3.jpg" alt="" />
											<h2>10 Hari</h2>
											<h5>Ayat-Ayat Cinta</h5>
											<p>Habiburrahman El Shirazy</p>
											<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>10 Hari</h2>
												<h4>Ayat-Ayat Cinta</h4>
												<p>Habiburrahman El Shirazy</p>
												<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
											</div>
										</div>
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
									</ul>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="images/home/buku4.jpg" alt="" />
											<h2>30 Hari</h2>
											<h5>The Power of Habit</h5>
											<p>Charles Duhigg</p>
											<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>30 Hari</h2>
												<h4>The Power of Habit</h4>
												<p>Charles Duhigg</p>
												<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
											</div>
										</div>
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
									</ul>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="images/home/buku5.jpg" alt="" />
											<h2>30 Hari</h2>
											<h5>Emotional Intteligence</h5>
											<p>Daniel Goleman</p>
											<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>30 Hari</h2>
												<h4>Emotional Intelligence</h4>
												<p>Daniel Goleman</p>
												<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
											</div>
										</div>
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
									</ul>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="images/home/buku6.jpg" alt="" />
											<h2>21 Hari</h2>
											<h5>Cosmos</h5>
											<p>Carl Sagan</p>
											<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>7 Hari</h2>
												<h4>Cosmos</h4>
												<p>Carl Sagan</p>
												<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
											</div>
										</div>
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
									</ul>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="images/home/buku14.jpg" alt="" />
											<h2>21 Hari</h2>
											<h5>Tilawah, Tajwid & Ghorib</h5>
											<p>Hanifa</p>
											<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>21 Hari</h2>
												<h4>Tilawah, Tajwid & Ghorib</h4>
												<p>Hanifa</p>
												<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
											</div>
										</div>
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
									</ul>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="images/home/buku8.jpg" alt="" />
											<h2>12 Hari</h2>
											<h5>Krisi Finansial</h5>
											<p>Adam Khoo</p>
											<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>12 Hari</h2>
												<h4>Krisis Finansial</h4>
												<p>Adam Khoo</p>
												<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
											</div>
										</div>
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
									</ul>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="images/home/buku13.jpg" alt="" />
											<h2>14 Hari</h2>
											<h5>Psikologi Kepribadian</h5>
											<p>Aksol</p>
											<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>14 Hari</h2>
												<h4>Psikologi Kepribadian</h4>
												<p>Aksol</p>
												<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
											</div>
										</div>
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
									</ul>
								</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="images/home/buku10.jpg" alt="" />
											<h2>14 Hari</h2>
											<h5>Sejarah Sumatra</h5>
											<p>Eriken Gerezs</p>
											<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>14 Hari</h2>
												<h4>Sejarah Sumatra</h4>
												<p>Eriken Gerezs</p>
												<a href="#" class="btn btn-default add-to-cart"></i>Pinjam Buku</a>
											</div>
										</div>
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
									</ul>
								</div>
							</div>
						</div>

						
					</div><!--features_items-->
					
					<div class="recommended_items"><!--recommended_items-->
						<h2 class="title text-center">Event Buku Gunung Putri</h2>		
						<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner">
								<div class="item active">	
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="images/home/bker.jpg" alt="" />
													<h2>Launching Kintir</h2>
													<p>Tiara Yudhistira Bercerita</p>
													<a href="#" class="btn btn-default add-to-cart"></i>Cek</a>
												</div>
												
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="images/home/bker2.jpg" alt="" />
													<h2>Pameran Seni & Buku</h2>
													<p>Kampung Teratai</p>
													<a href="#" class="btn btn-default add-to-cart"></i>Cek</a>
												</div>
												
											</div>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="images/home/bker3.jpg" alt="" />
													<h2>Diskusi Buku</h2>
													<p>Tour Life</p>
													<a href="#" class="btn btn-default add-to-cart"></i>Cek</a>
												</div>
												
											</div>
										</div>
									</div>
								</div>

								
							</div>
							 <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
								<i class="fa fa-angle-left"></i>
							  </a>
							  <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
								<i class="fa fa-angle-right"></i>
							  </a>			
						</div>
					</div><!--/recommended_items-->
				</div>
			</div>
		</div>
	</section>
	
	<footer id="footer"><!--Footer-->
		<div class="footer-top">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="companyinfo">
							<h2><span>Read</span>me</h2>
							<p>Yok baca yok</p>
						</div>
					</div>
					
					<div class="col-sm-3 col-sm-offset-1">
						<div class="single-widget">
							<h2>Tentang Readme</h2>
							<form action="#" class="searchform">
								<input type="text" placeholder="Your email address" />
								<button type="submit" class="btn btn-default"><i class="fa fa-arrow-circle-o-right"></i></button>
								<p>Dapatkan informasi terupdate <br> mengenai buku ataupun berita baru <br> dari kami </p>
							</form>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyright © 2020 Readme Inc. All rights reserved.</p>
					<p class="pull-right">Designed by <span><a target="_blank" href="https://www.instagram.com/sidik_purba/">Sidik Purba</a></span></p>
				</div>
			</div>
		</div>
		
		


	</footer><!--/Footer-->
	

  
    <script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
	<script src="js/price-range.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>
</body>
</html>

