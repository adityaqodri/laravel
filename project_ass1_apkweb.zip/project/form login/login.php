<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<form name="login" id="login" action="login_post.php" method="post">
<table width="533" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="154" rowspan="5" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td height="32" colspan="4" align="left" valign="center"> Login To System </td>
  </tr>
  <tr>
    <td width="137" height="26" align="right" valign="center">User ID </td>
    <td width="9" align="center" valign="center">:</td>
    <td colspan="2" valign="center"><input name="userid" type="text" id="userid" maxlength="10" /></td>
  </tr>
  <tr>
    <td height="26" align="right" valign="center">Password</td>
    <td align="center" valign="center">:</td>
    <td colspan="2" valign="center"><input name="password" type="password" id="password" maxlength="10" /></td>
  </tr>
  
  <tr>
    <td height="2" colspan="4" valign="top"><hr /></td>
  </tr>
  <tr>
    <td height="26" colspan="3" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td width="91" align="right" valign="center">
      
      <div align="center">
        <input type="submit" name="Submit" value="Submit" />
      </div></td>
  </tr>
  <tr>
    <td height="2"></td>
    <td></td>
    <td></td>
    <td width="147"></td>
    <td></td>
  </tr>
</table>
</form>
</body>
</html>
