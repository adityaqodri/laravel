<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<form name="login" id="login" action="login_post.php" method="post">
<table width="454" height="235" border="0" cellpadding="0" cellspacing="0" background="../image/login.jpg" >
  <tr>
    <td width="335" rowspan="6" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td width="119" height="13"></td>
  </tr>
  <tr>
    <td height="59" align="center" valign="middle"></td>
  </tr>
  
  <tr>
    <td height="33" align="center" valign="middle"><input name="userid" type="text" id="userid" size="10" maxlength="10" /></td>
  </tr>
  <tr>
    <td height="34" align="center" valign="middle"><input name="password" type="password" id="password" size="10" maxlength="8" /></td>
  </tr>
  <tr>
		<input type="checkbox" name="remember" id="remember" />
		<label for="remember">Remember Me</label>
  </tr>
  <tr>
    <td height="34" align="center" valign="middle"><input name="Login" type="submit" id="Login" value="Login" class="btn btn-primary" /></td>
  </tr>
  <tr>
    <td height="42" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
  <tr>
    <td height="20" valign"middle" align="right">Not registered?<a href="register.php">Create an account</a></td>
    <td valign="top"></td>
  </tr> 
</table>
</form>
</body>
</html>
