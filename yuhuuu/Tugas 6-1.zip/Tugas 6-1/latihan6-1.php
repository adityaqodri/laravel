<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>


<body bgcolor="#fff">
	<br/>
<form name="kaleng" id="kaleng" method="post" action="kalengcek.php">
<table align="center"width="341" border="0" cellpadding="0" cellspacing="0">
	  <!--DWLayoutTable-->
  	<tr bgcolor="#66CC99">
    	<td width="98" height="40" align="right" valign="middle"><div align="center">Jumlah kaleng </div></td>
    	<td width="22" valign='middle'><div align="center">:</div></td>
	  	<td width="221" valign='middle'><input name="jumlahkaleng" type="text" id="jumlahkaleng" /></td>
  	</tr>
	<tr bgcolor="#CCCC00">
  		<td height="34" align="center" valign="middle"><input type="submit" name="Submit" value="Submit" /> </td>
   		 <td colspan="2" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
  	</tr>
</table>
</form>
		
		
</body>
</html>
